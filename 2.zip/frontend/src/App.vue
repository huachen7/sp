<template>
  <div class="min-h-screen">
    <router-view />
  </div>
</template> 